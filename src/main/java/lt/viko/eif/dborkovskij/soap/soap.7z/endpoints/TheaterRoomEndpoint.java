package lt.viko.eif.dborkovskij.soap.endpoints;

import lt.viko.eif.dborkovskij.soap.localhost.cinema.theaterroom.*;
import lt.viko.eif.dborkovskij.soap.HotelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

@Endpoint
public class RoomEndpoint {
    private static final String URI = "http://localhost/hotel/room";
    @Autowired
    private HotelService hotelService;

    public RoomEndpoint(HotelService hotelService) {
        this.hotelService = hotelService;
    }

    @PayloadRoot(namespace = URI, localPart = "getRoomRequest")
    @ResponsePayload
    public GetRoomResponse getRoom(@RequestPayload GetRoomRequest request){
        GetRoomResponse response = new GetRoomResponse();
        response.setRoom(hotelService.hotelRepository.get(request.getId()));
        return response;
    }

    @PayloadRoot(namespace = URI, localPart = "getRoomsRequest")
    @ResponsePayload
    public GetRoomsResponse getRoomsResponse(@RequestPayload GetRoomRequest request){
        GetRoomsResponse response = new GetRoomsResponse();
        response.getRoom().addAll(hotelService.hotelRepository.getAll());
        return response;
    }

    @PayloadRoot(namespace = URI, localPart = "insertRoomRequest")
    @ResponsePayload
    public InsertRoomResponse insertRoom(@RequestPayload InsertRoomRequest request){
        hotelService.hotelRepository.insert(request.getRoom());
        ServiceStatus serviceStatus = new ServiceStatus();
        serviceStatus.setStatusCode("201");
        serviceStatus.setMessage("Room was inserted");
        InsertRoomResponse response = new InsertRoomResponse();
        response.setServiceStatus(serviceStatus);
        return response;
    }

    @PayloadRoot(namespace = URI, localPart = "updateRoomRequest")
    @ResponsePayload
    public UpdateRoomResponse updateRoomResponse(@RequestPayload UpdateRoomRequest request){
        hotelService.hotelRepository.update(request.getRoom());
        ServiceStatus serviceStatus = new ServiceStatus();
        serviceStatus.setStatusCode("204");
        serviceStatus.setMessage("Room was updated");
        UpdateRoomResponse response = new UpdateRoomResponse();
        response.setServiceStatus(serviceStatus);
        return response;
    }

    @PayloadRoot(namespace = URI, localPart = "deleteRoomRequest")
    @ResponsePayload
    public DeleteRoomResponse deleteRoomResponse(@RequestPayload DeleteRoomRequest request){
        hotelService.hotelRepository.delete(request.getId());
        ServiceStatus serviceStatus = new ServiceStatus();
        serviceStatus.setStatusCode("204");
        serviceStatus.setMessage("Room was deleted");
        DeleteRoomResponse response = new DeleteRoomResponse();
        response.setServiceStatus(serviceStatus);
        return response;
    }
}
